import firebase from "firebase";

const firebaseConfig = {
    apiKey: "AIzaSyA5KQBtNa3gsYY-Od70dubNq1W-JyRyooA",
    authDomain: "clone-a1fa7.firebaseapp.com",
    projectId: "clone-a1fa7",
    storageBucket: "clone-a1fa7.appspot.com",
    messagingSenderId: "615229076966",
    appId: "1:615229076966:web:afdc6946189fd8fb3d9227",
    measurementId: "G-MDL4FLHGZL"
  };

const firebaseApp = firebase.initializeApp(firebaseConfig);

const db = firebaseApp.firestore();
const auth = firebase.auth();

export { db, auth };